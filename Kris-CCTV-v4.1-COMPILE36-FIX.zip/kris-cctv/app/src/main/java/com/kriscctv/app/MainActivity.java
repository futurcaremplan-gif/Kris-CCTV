package com.kriscctv.app;

import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.rtsp.RtspMediaSource;
import androidx.media3.ui.PlayerView;

public class MainActivity extends AppCompatActivity {
    private static final String PREFS = "kris_cctv";
    private ExoPlayer player;
    private PlayerView playerView;
    private TextView status;
    private EditText[] urls = new EditText[5];
    private Button[] testButtons = new Button[5];
    private SharedPreferences prefs;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        status = findViewById(R.id.status);
        playerView = findViewById(R.id.player_view);

        int[] ids = {R.id.url1, R.id.url2, R.id.url3, R.id.url4, R.id.url5};
        int[] btnIds = {R.id.test1, R.id.test2, R.id.test3, R.id.test4, R.id.test5};
        for (int i = 0; i < 5; i++) {
            final int index = i;
            urls[i] = findViewById(ids[i]);
            testButtons[i] = findViewById(btnIds[i]);
            String saved = prefs.getString("url" + (i + 1), "");
            if (!saved.isEmpty()) urls[i].setText(saved);
            testButtons[i].setOnClickListener(v -> playCamera(index));
        }

        if (urls[0].getText().length() == 0) {
            urls[0].setText("rtsp://192.168.1.1:554/live/ch00_1");
        }

        findViewById(R.id.save).setOnClickListener(v -> saveUrls());
        findViewById(R.id.stop).setOnClickListener(v -> stopPlayer());
        findViewById(R.id.fullscreen).setOnClickListener(v -> togglePlayerArea());
        findViewById(R.id.setup).setOnClickListener(v -> showSetup());

        status.setText("Ready • Camera 1 RTSP test is prefilled");
    }

    private void saveUrls() {
        SharedPreferences.Editor e = prefs.edit();
        for (int i = 0; i < 5; i++) e.putString("url" + (i + 1), urls[i].getText().toString().trim());
        e.apply();
        Toast.makeText(this, "Camera addresses saved", Toast.LENGTH_SHORT).show();
    }

    private void playCamera(int index) {
        String u = urls[index].getText().toString().trim();
        if (u.isEmpty()) {
            status.setText("Camera " + (index + 1) + " has no RTSP address.");
            return;
        }
        saveUrls();
        stopPlayer();
        status.setText("Connecting to Camera " + (index + 1) + "…");
        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        playerView.setVisibility(View.VISIBLE);

        // Start with the standard RTSP transport (RTP/UDP). Media3 can automatically
        // retry using RTP-over-TCP if UDP packets do not arrive. Some inexpensive
        // V380/OEM cameras work in VLC over UDP but fail when TCP is forced.
        RtspMediaSource.Factory factory = new RtspMediaSource.Factory()
                .setTimeoutMs(8000);
        MediaItem item = MediaItem.fromUri(Uri.parse(u));
        player.setMediaSource(factory.createMediaSource(item));
        player.addListener(new Player.Listener() {
            @Override public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_READY) {
                    status.setText("● LIVE • Camera " + (index + 1));
                }
            }
            @Override public void onPlayerError(PlaybackException error) {
                status.setText("Camera " + (index + 1) + " failed: " + error.getErrorCodeName());
            }
        });
        player.prepare();
        player.play();
    }

    private void stopPlayer() {
        if (player != null) {
            player.release();
            player = null;
        }
        if (playerView != null) playerView.setPlayer(null);
        if (status != null) status.setText("Stopped");
    }

    private void togglePlayerArea() {
        if (playerView.getVisibility() == View.VISIBLE) {
            playerView.setVisibility(View.GONE);
        } else {
            playerView.setVisibility(View.VISIBLE);
        }
    }

    private void showSetup() {
        new AlertDialog.Builder(this)
                .setTitle("Kris CCTV • Setup")
                .setMessage("Camera 1 has been verified with this RTSP address:\n\nrtsp://192.168.1.1:554/live/ch00_1\n\nThat address works only while the phone is directly connected to the camera's MV61975156 setup Wi‑Fi. For remote viewing by family, the cameras must first be connected to the home router and then we will add secure remote access. Do not expose RTSP port 554 directly to the public internet.")
                .setPositiveButton("OK", null)
                .show();
    }

    @Override protected void onStop() {
        super.onStop();
        if (player != null) {
            player.release();
            player = null;
        }
    }
}
