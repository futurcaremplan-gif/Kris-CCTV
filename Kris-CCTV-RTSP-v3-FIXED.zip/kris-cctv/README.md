# Kris CCTV

Native Android RTSP viewer prototype for up to 5 cameras.

## Verified Camera 1 stream
`rtsp://192.168.1.1:554/live/ch00_1`

This was verified with VLC on the camera's direct Wi-Fi AP (`MV61975156`).

## Important
The 192.168.1.1 address is a local setup/AP address. It is not a remote Internet address. For remote family viewing, connect the camera to the home router and then configure secure remote access. Do not expose RTSP port 554 directly to the public Internet.
